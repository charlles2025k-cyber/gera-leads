const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let queueRunning = false;

// --- INICIALIZAÇÃO E ALARMES (KEEPALIVE) ---
chrome.runtime.onInstalled.addListener(() => {
  console.log('ZapFlow Service Worker Instalado.');
  // Alarme de segurança para re-despertar o SW se suspenso
  chrome.alarms.create('keepalive', { periodInMinutes: 1 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive') {
    // Apenas mantém o Service Worker vivo
    if (!queueRunning) {
      verificarEIniciarFila();
    }
  }
});

// --- ESCUTA DE MENSAGENS ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'START_CAMPAIGN') {
    verificarEIniciarFila();
    sendResponse({ sucesso: true });
    return true;
  }

  if (request.action === 'PAUSE_CAMPAIGN') {
    pausarCampanhaAtiva();
    sendResponse({ sucesso: true });
    return true;
  }

  if (request.action === 'RESUME_CAMPAIGN') {
    resumirCampanhaAtiva();
    sendResponse({ sucesso: true });
    return true;
  }

  if (request.action === 'CANCEL_CAMPAIGN') {
    cancelarCampanhaAtiva();
    sendResponse({ sucesso: true });
    return true;
  }

  if (request.action === 'RUN_DIAGNOSTIC') {
    obterAbaWhatsApp().then(async (tab) => {
      if (!tab) {
        sendResponse({ sucesso: false, erro: 'whatsapp_nao_aberto' });
        return;
      }
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            return {
              titulo: document.title,
              url_real: window.location.href,
              body_classes: document.body?.className?.substring(0, 100),
              total_divs: document.querySelectorAll('div').length,
              editables: Array.from(document.querySelectorAll('[contenteditable]')).map(el => ({
                tag: el.tagName,
                contenteditable: el.getAttribute('contenteditable'),
                role: el.getAttribute('role'),
                dataTab: el.getAttribute('data-tab')
              })),
              footer_html: document.querySelector('footer')?.innerHTML?.substring(0, 300) || 'nao encontrado',
              spans_data_icon: Array.from(document.querySelectorAll('span[data-icon]')).map(el => el.getAttribute('data-icon')).slice(0, 20)
            };
          }
        });

        console.log('DIAGNOSTICO:', JSON.stringify(results[0]?.result, null, 2));
        await registrarDebugLog('DIAG', tab.url, 'Diagnóstico Manual: ' + JSON.stringify(results[0]?.result, null, 2));
        sendResponse({ sucesso: true, resultado: results[0]?.result });
      } catch (err) {
        await registrarDebugLog('DIAG', tab.url, `Erro no diagnóstico manual: ${err.message}`);
        sendResponse({ sucesso: false, erro: err.message });
      }
    });
    return true;
  }

  if (request.action === 'INCOMING_MESSAGE') {
    console.log(`[ZapFlow BG] Recebido INCOMING_MESSAGE para o telefone: ${request.phone}, texto: "${request.text}"`);
    processarMensagemRecebida(request.phone, request.text).catch(err => {
      console.error('[ZapFlow BG] Erro ao processar mensagem recebida:', err);
    });
    sendResponse({ sucesso: true, status: 'recebido' });
    return true;
  }
});

// --- ENVIADOR DE MENSAGENS EM MASSA (FILA) ---
function verificarEIniciarFila() {
  if (queueRunning) return;
  queueRunning = true;
  
  chrome.storage.local.get(['campanha_ativa'], (res) => {
    const camp = res.campanha_ativa;
    
    if (camp && camp.status === 'em_andamento') {
      processarFilaMensagens().catch(err => {
        console.error('Erro na fila de disparos:', err);
        queueRunning = false;
      });
    } else {
      queueRunning = false;
    }
  });
}

async function processarFilaMensagens() {
  queueRunning = true;
  
  while (queueRunning) {
    const res = await chrome.storage.local.get(['campanha_ativa', 'campanha_logs']);
    const camp = res.campanha_ativa;
    const logs = res.campanha_logs || [];

    if (!camp || camp.status !== 'em_andamento') {
      queueRunning = false;
      break;
    }

    if (camp.fila.length === 0) {
      // Fila concluída
      camp.status = 'concluida';
      await salvarResumoCampanha(camp);
      queueRunning = false;
      break;
    }

    // Retira o primeiro contato da fila
    const contato = camp.fila.shift();
    
    // Configura delay aleatório entre min e max segundos
    const delay = Math.floor(Math.random() * (camp.delay_max - camp.delay_min + 1) + camp.delay_min) * 1000;
    await wait(delay);

    // Localizar aba do WhatsApp Web
    const tab = await obterAbaWhatsApp();
    if (!tab) {
      // Pausar se o WhatsApp Web não estiver aberto
      camp.status = 'pausada';
      camp.fila.unshift(contato); // Devolve contato para a fila
      
      await chrome.storage.local.set({ campanha_ativa: camp });
      
      logs.push({
        numero: contato.numero,
        nome: contato.nome,
        status: 'erro',
        erro: 'WhatsApp Web não encontrado',
        horario: new Date().toLocaleTimeString()
      });
      await chrome.storage.local.set({ campanha_logs: logs });
      
      queueRunning = false;
      break;
    }

    // Substituir variáveis na mensagem
    let mensagemTratada = camp.mensagem
      .replace(/\{\{nome\}\}/gi, contato.nome)
      .replace(/\{\{numero\}\}/gi, contato.numero);

    let statusEnvio = 'erro';
        try {
      // Abrir nova aba, esperar carregar, injetar script e fechar
      const resposta = await enviarMensagemWhatsApp(contato.numero, mensagemTratada);

      if (resposta && resposta.sucesso) {
        statusEnvio = 'enviado';
        camp.enviados++;
      } else {
        statusEnvio = (resposta && resposta.erro === 'numero_invalido') ? 'invalido' : 'erro';
        if (statusEnvio === 'invalido') {
          camp.ignorados++;
        } else {
          camp.erros++;
        }
      }
    } catch (err) {
      statusEnvio = 'erro';
      camp.erros++;
    }

    // Registrar log
    logs.push({
      numero: contato.numero,
      nome: contato.nome,
      status: statusEnvio,
      horario: new Date().toLocaleTimeString()
    });

    camp.progresso = camp.enviados + camp.erros + camp.ignorados;
    
    // Atualizar no storage
    await chrome.storage.local.set({
      campanha_ativa: camp,
      campanha_logs: logs
    });

    // Incrementar disparos localmente se foi enviado com sucesso
    if (statusEnvio === 'enviado') {
      await incrementarDisparosLocal(1);
      await syncDisparosToSupabase();
    }
  }
}

async function pausarCampanhaAtiva() {
  const res = await chrome.storage.local.get(['campanha_ativa']);
  const camp = res.campanha_ativa;
  if (camp) {
    camp.status = 'pausada';
    await chrome.storage.local.set({ campanha_ativa: camp });
  }
}

async function resumirCampanhaAtiva() {
  const res = await chrome.storage.local.get(['campanha_ativa']);
  const camp = res.campanha_ativa;
  if (camp) {
    camp.status = 'em_andamento';
    await chrome.storage.local.set({ campanha_ativa: camp });
    verificarEIniciarFila();
  }
}

async function cancelarCampanhaAtiva() {
  queueRunning = false;
  const res = await chrome.storage.local.get(['campanha_ativa']);
  const camp = res.campanha_ativa;
  
  if (camp) {
    camp.status = 'cancelada';
    await salvarResumoCampanha(camp);
  }
}

// --- CONTROLE DE DISPAROS LOCAL ---
async function incrementarDisparosLocal(quantidade) {
  return new Promise((resolve) => {
    chrome.storage.local.get(['zapflow_license'], (res) => {
      const license = res.zapflow_license;
      if (license) {
        license.disparos_usados = (license.disparos_usados || 0) + quantidade;
        chrome.storage.local.set({ zapflow_license: license }, () => {
          resolve();
        });
      } else {
        resolve();
      }
    });
  });
}

async function syncDisparosToSupabase() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['zapflow_license'], async (res) => {
      const license = res.zapflow_license;
      if (!license || !license.license_key) {
        console.error('[ZapFlow BG] Licença não encontrada no storage local.');
        resolve();
        return;
      }
      
      const licenseKey = license.license_key;
      const disparosUsados = license.disparos_usados || 0;
      
      try {
        const url = `https://zmozmydchgkunyxuwhgh.supabase.co/rest/v1/zapflow_licenses?license_key=eq.${encodeURIComponent(licenseKey)}`;
        const anonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inptb3pteWRjaGdrdW55eHV3aGdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MjE2OTQsImV4cCI6MjA5NzM5NzY5NH0.dRKizn_OUA7e3bYxcJCQkEhDUq4h5lsRbQCe9dovPLo';
        
        const response = await fetch(url, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'apikey': anonKey,
            'Authorization': `Bearer ${anonKey}`,
            'Prefer': 'return=representation'
          },
          body: JSON.stringify({
            disparos_usados: disparosUsados
          })
        });
        
        if (!response.ok) {
          console.error('[ZapFlow BG] Erro ao sincronizar disparos com Supabase:', response.statusText);
        } else {
          console.log('[ZapFlow BG] Disparos sincronizados com o Supabase com sucesso.');
        }
      } catch (err) {
        console.error('[ZapFlow BG] Erro de rede ao sincronizar disparos:', err);
      } finally {
        resolve();
      }
    });
  });
}

async function salvarResumoCampanha(camp) {
  // Atualiza gráfico semanal de disparos
  if (camp.enviados > 0) {
    try {
      await atualizarGraficoDisparos(camp.enviados);
    } catch (err) {
      console.error('Erro ao atualizar gráfico de disparos:', err);
    }
  }

  // Exclui do storage quando concluído/cancelado
  await chrome.storage.local.remove(['campanha_ativa']);
}

async function atualizarGraficoDisparos(quantidade) {
  const hojeStr = new Date().toISOString().split('T')[0];
  const res = await chrome.storage.local.get(['disparos_semana']);
  let dados = res.disparos_semana || [];

  const index = dados.findIndex(d => d.data === hojeStr);
  if (index !== -1) {
    dados[index].total += quantidade;
  } else {
    dados.push({ data: hojeStr, total: quantidade });
  }

  // Ordena por data e filtra para manter apenas últimos 7 dias
  dados.sort((a, b) => new Date(a.data) - new Date(b.data));
  if (dados.length > 7) {
    dados = dados.slice(-7);
  }

  await chrome.storage.local.set({ disparos_semana: dados });
}

// --- AUXILIARES TABS ---
async function obterAbaWhatsApp() {
  return new Promise((resolve) => {
    chrome.tabs.query({ url: '*://web.whatsapp.com/*' }, (tabs) => {
      if (tabs.length === 0) {
        resolve(null);
      } else {
        // Retorna a aba já carregada ou a primeira da lista
        const activeTab = tabs.find(t => t.status === 'complete') || tabs[0];
        resolve(activeTab);
      }
    });
  });
}

function enviarMensagemParaAba(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

async function registrarDebugLog(numero, url, msg, infoAdicional = {}) {
  const res = await chrome.storage.local.get(['debug_logs']);
  const logs = res.debug_logs || [];
  
  logs.push({
    timestamp: new Date().toISOString(),
    horario: new Date().toLocaleTimeString(),
    numero,
    url,
    mensagem: msg,
    info: infoAdicional
  });

  await chrome.storage.local.set({ debug_logs: logs });
}

let sendingLock = false;

async function enviarMensagemWhatsApp(numero, texto) {
  while (sendingLock) {
    await wait(500);
  }
  sendingLock = true;

  try {
    const tab = await obterAbaWhatsApp();
    if (!tab) {
      await registrarDebugLog(numero, '', 'WhatsApp Web não está aberto');
      return { sucesso: false, erro: 'whatsapp_nao_aberto' };
    }

    const encodedText = encodeURIComponent(texto);
    const url = `https://web.whatsapp.com/send?phone=${numero}&text=${encodedText}`;
    await registrarDebugLog(numero, url, 'Iniciando navegação da aba via chrome.tabs.update');

    // Passo 1: navegar a aba existente
    await chrome.tabs.update(tab.id, { url });

    // Passo 2: aguardar a aba terminar de carregar
    await new Promise((resolve) => {
      const listener = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 15000);
    });

    await registrarDebugLog(numero, url, 'Aba recarregada. Iniciando polling de renderização por até 20 segundos...');

    // Passo 3: Polling para aguardar o botão enviar ou o input editável aparecer
    let sendBtn = null;
    for (let i = 0; i < 20; i++) {
      await wait(1000);
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const btn = document.querySelector("span[data-icon='send']") ||
                      document.querySelector("button[data-testid='send']") ||
                      document.querySelector("div[role='button'][aria-label='Enviar']") ||
                      document.querySelector("div[role='button'][aria-label='Send']");
          if (btn) return { encontrado: true };
          const input = document.querySelector('div[contenteditable="true"]');
          if (input) return { encontrado: false, temInput: true };
          return { encontrado: false, temInput: false };
        }
      });
      const res = results[0]?.result;
      if (res?.encontrado || res?.temInput) {
        sendBtn = res;
        break;
      }
    }

    if (!sendBtn) {
      await registrarDebugLog(numero, url, 'Aviso: Polling finalizado sem encontrar botão de envio ou input');
    } else {
      await registrarDebugLog(numero, url, `Polling finalizado: Botão encontrado: ${sendBtn.encontrado}, Input encontrado: ${sendBtn.temInput}`);
    }

    // Passo 4: Executar o envio da mensagem
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const btn = document.querySelector("span[data-icon='send']") ||
                    document.querySelector("button[data-testid='send']") ||
                    document.querySelector("div[role='button'][aria-label='Enviar']") ||
                    document.querySelector("div[role='button'][aria-label='Send']");
        if (btn) {
          btn.click();
          return { sucesso: true };
        }
        const input = document.querySelector('div[contenteditable="true"]');
        if (input) {
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
          return { sucesso: true };
        }
        return { sucesso: false, erro: 'nao_encontrado' };
      }
    });

    const executionResult = results[0]?.result || { sucesso: false, erro: 'script_falhou' };
    await registrarDebugLog(numero, url, 'Resultado do Envio: ' + JSON.stringify(executionResult, null, 2));

    await wait(1000);
    return executionResult;
  } catch (err) {
    await registrarDebugLog(numero, url, `Erro no envio da mensagem: ${err.message}`);
    return { sucesso: false, erro: err.message };
  } finally {
    sendingLock = false;
  }
}

// --- SISTEMA DE FUNIL DE RESPOSTAS ---

async function processarMensagemRecebida(phone, text) {
  console.log(`[ZapFlow BG] processarMensagemRecebida chamado para: ${phone}, texto: "${text}"`);
  await registrarDebugLog(phone, '', `Mensagem recebida observada: "${text}"`);

  const res = await chrome.storage.local.get(['funnels', 'funil_ativo']);
  const funnels = res.funnels || [];
  const funilAtivo = res.funil_ativo || {};

  // Se já está no funil e o status é 'em_funil':
  // Um novo recado foi recebido do contato enquanto ele estava no meio do funil
  // -> Interrompe o funil e marca como 'convertido'
  if (funilAtivo[phone] && funilAtivo[phone].status === 'em_funil') {
    funilAtivo[phone].status = 'convertido';
    funilAtivo[phone].lastUpdated = Date.now();
    await chrome.storage.local.set({ funil_ativo: funilAtivo });
    await registrarDebugLog(phone, '', `Contato respondeu novamente no funil! Status atualizado para: 'convertido'`);
    console.log(`[ZapFlow BG] Contato ${phone} respondeu novamente no funil! Status alterado para: 'convertido'`);
    return;
  }

  // Se já foi convertido ou concluído sem resposta, ignoramos
  if (funilAtivo[phone] && (funilAtivo[phone].status === 'convertido' || funilAtivo[phone].status === 'concluido_sem_resposta')) {
    console.log(`[ZapFlow BG] Contato ${phone} já está com status ${funilAtivo[phone].status}. Ignorando.`);
    return;
  }

  // Verificar se há funis ativos que correspondam aos gatilhos
  const activeFunnels = funnels.filter(f => f.active);
  console.log(`[ZapFlow BG] Total de funis ativos cadastrados: ${activeFunnels.length}`);
  if (activeFunnels.length === 0) return;

  const normalizedText = normalizeString(text);
  const matchedFunnel = activeFunnels.find(f => {
    const triggers = f.triggers.split(',').map(t => normalizeString(t)).filter(t => t.length > 0);
    console.log(`[ZapFlow BG] Testando funil "${f.name}" com gatilhos [${triggers.join(', ')}] contra "${normalizedText}"`);
    return triggers.some(t => normalizedText.includes(t));
  });

  if (matchedFunnel) {
    // Buscar o nome do contato nos logs ou fila da campanha ativa para personalizar
    const contactName = await obterNomeContato(phone);
    console.log(`[ZapFlow BG] Matched Funil: "${matchedFunnel.name}". Contact Name: "${contactName}"`);

    await registrarDebugLog(phone, '', `Gatilho acionado para o funil "${matchedFunnel.name}". Iniciando etapa 1...`);
    
    funilAtivo[phone] = {
      funnelId: matchedFunnel.id,
      step: 0,
      status: 'em_funil',
      nome: contactName,
      lastUpdated: Date.now()
    };

    await chrome.storage.local.set({ funil_ativo: funilAtivo });
    console.log(`[ZapFlow BG] Gravado funil_ativo no local storage para ${phone}. Disparando executarProximoPassoFunil...`);
    
    // Inicia a execução assíncrona do funil para o contato
    executarProximoPassoFunil(phone).catch(err => {
      console.error(`Erro ao executar passo de funil para ${phone}:`, err);
    });
  }
}


async function executarProximoPassoFunil(phone) {
  console.log(`[ZapFlow BG] executarProximoPassoFunil chamado para: ${phone}`);
  const res = await chrome.storage.local.get(['funil_ativo', 'funnels']);
  const funilAtivo = res.funil_ativo || {};
  const state = funilAtivo[phone];
  console.log(`[ZapFlow BG] Estado atual do contato ${phone}:`, JSON.stringify(state));
  if (!state || state.status !== 'em_funil') return;

  const funnels = res.funnels || [];
  const funnel = funnels.find(f => f.id === state.funnelId);
  if (!funnel || !funnel.active) return;

  const stepIndex = state.step;
  const messages = funnel.messages || [];

  // Se todas as mensagens do funil foram enviadas
  if (stepIndex >= messages.length) {
    state.status = 'concluido_sem_resposta';
    state.lastUpdated = Date.now();
    await chrome.storage.local.set({ funil_ativo: funilAtivo });
    await registrarDebugLog(phone, '', `Funil concluído sem resposta secundária.`);
    return;
  }

  const currentMsgObj = messages[stepIndex];
  
  // Configura delay aleatório
  const delaySec = Math.floor(Math.random() * (currentMsgObj.delay_max - currentMsgObj.delay_min + 1) + currentMsgObj.delay_min);
  await wait(delaySec * 1000);

  // Re-verificar estado após o delay
  const resCheck = await chrome.storage.local.get(['funil_ativo']);
  const activeStates = resCheck.funil_ativo || {};
  const currentState = activeStates[phone];

  if (!currentState || currentState.status !== 'em_funil' || currentState.step !== stepIndex) {
    await registrarDebugLog(phone, '', `Cancelado: Etapa do funil cancelada pois o status mudou durante o delay.`);
    return;
  }

  // Substituir variáveis
  let mensagemTratada = currentMsgObj.text
    .replace(/\{\{nome\}\}/gi, currentState.nome || 'Contato')
    .replace(/\{\{numero\}\}/gi, phone);

  await registrarDebugLog(phone, '', `Enviando mensagem do funil (Etapa ${stepIndex + 1}/${messages.length}) após delay de ${delaySec}s...`);

  // Enviar utilizando a função coordenada thread-safe
  const resposta = await enviarMensagemWhatsApp(phone, mensagemTratada);

  if (resposta && resposta.sucesso) {
    // Atualiza para o próximo passo
    const resUpdate = await chrome.storage.local.get(['funil_ativo']);
    const activeStatesUpdate = resUpdate.funil_ativo || {};
    if (activeStatesUpdate[phone] && activeStatesUpdate[phone].status === 'em_funil' && activeStatesUpdate[phone].step === stepIndex) {
      activeStatesUpdate[phone].step += 1;
      activeStatesUpdate[phone].lastUpdated = Date.now();
      await chrome.storage.local.set({ funil_ativo: activeStatesUpdate });
      
      // Incrementar disparos localmente e gráfico
      await incrementarDisparosLocal(1);
      await syncDisparosToSupabase();
      await atualizarGraficoDisparos(1);

      // Recursão para a próxima etapa do funil
      executarProximoPassoFunil(phone).catch(err => {
        console.error(`Erro ao rodar etapa seguinte do funil para ${phone}:`, err);
      });
    }
  } else {
    await registrarDebugLog(phone, '', `Erro no envio da mensagem do funil: ${resposta ? resposta.erro : 'Erro desconhecido'}`);
    // Se falhou, re-tenta em 15 segundos se o status continuar em_funil
    setTimeout(() => {
      executarProximoPassoFunil(phone).catch(err => {});
    }, 15000);
  }
}

// --- AUXILIARES DO FUNIL ---

function normalizeString(str) {
  if (!str) return '';
  return str
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

async function isInActiveCampaignList(phone) {
  const res = await chrome.storage.local.get(['campanha_ativa', 'campanha_logs']);
  const camp = res.campanha_ativa;
  const logs = res.campanha_logs || [];

  if (camp && camp.fila) {
    const inFila = camp.fila.some(c => c.numero === phone);
    if (inFila) return true;
  }

  const inLogs = logs.some(l => l.numero === phone);
  if (inLogs) return true;

  return false;
}

async function obterNomeContato(phone) {
  const res = await chrome.storage.local.get(['campanha_ativa', 'campanha_logs']);
  const camp = res.campanha_ativa;
  const logs = res.campanha_logs || [];

  if (camp && camp.fila) {
    const found = camp.fila.find(c => c.numero === phone);
    if (found && found.nome) return found.nome;
  }

  const logged = logs.find(l => l.numero === phone);
  if (logged && logged.nome) return logged.nome;

  return 'Contato';
}
