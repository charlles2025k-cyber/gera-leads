import { storage } from '../lib/storage.js';
import { csvParser } from '../lib/csv_parser.js';

// Elementos DOM
const globalLoading = document.getElementById('global-loading');
const globalLoadingText = document.getElementById('global-loading-text');

// Containers Principais
const appContainer = document.getElementById('app-container');
const activationContainer = document.getElementById('activation-container');

// Elementos Ativação
const formActivation = document.getElementById('form-activation');
const activationKey = document.getElementById('activation-key');
const activationErrorMsg = document.getElementById('activation-error-msg');

// Views
const viewDashboard = document.getElementById('view-dashboard');
const viewDisparos = document.getElementById('view-disparos');
const viewConfiguracoes = document.getElementById('view-configuracoes');
const viewDebugLogs = document.getElementById('view-debug-logs');
const btnShowDebugLogs = document.getElementById('btn-show-debug-logs');
const btnRunDiagnostic = document.getElementById('btn-run-diagnostic');
const btnBackFromLogs = document.getElementById('btn-back-from-logs');
const btnClearDebugLogs = document.getElementById('btn-clear-debug-logs');
const btnCopyDebugLogs = document.getElementById('btn-copy-debug-logs');
const debugLogsTextarea = document.getElementById('debug-logs-textarea');

// Navegação
const navItems = document.querySelectorAll('.nav-item');
const btnSidebarLogout = document.getElementById('btn-sidebar-logout');
const btnConfigLogout = document.getElementById('btn-config-logout');

// Banner de Upgrade
const upgradeBanner = document.getElementById('upgrade-banner');
const btnCloseUpgrade = document.getElementById('btn-close-upgrade');
const expiredStatusBanner = document.getElementById('expired-status-banner');

// Elementos Dashboard
const dashWelcome = document.getElementById('dash-welcome');
const dashPlanBadge = document.getElementById('dash-plan-badge');
const whatsappStatusBanner = document.getElementById('whatsapp-status-banner');
const statDisparos = document.getElementById('stat-disparos');
const statDisparosHoje = document.getElementById('stat-disparos-hoje');
const statTotalCampanhas = document.getElementById('stat-total-campanhas');
const progressDisparos = document.getElementById('progress-disparos');
const dashChart = document.getElementById('dash-chart');

// Elementos Disparos
const formDisparos = document.getElementById('form-disparos');
const campName = document.getElementById('camp-name');
const contactsTextInput = document.getElementById('contacts-text-input');
const campMessage = document.getElementById('camp-message');
const msgCharCount = document.getElementById('msg-char-count');
const delayMin = document.getElementById('delay-min');
const delayMax = document.getElementById('delay-max');

const disparosActivePanel = document.getElementById('disparos-active-panel');
const activeCampTitle = document.getElementById('active-camp-title');
const activeCampProgressText = document.getElementById('active-camp-progress-text');
const activeCampProgressBar = document.getElementById('active-camp-progress-bar');
const activeCampLogs = document.getElementById('active-camp-logs');
const btnCampPause = document.getElementById('btn-camp-pause');
const btnCampResume = document.getElementById('btn-camp-resume');
const btnCampCancel = document.getElementById('btn-camp-cancel');

// Elementos Configurações
const configUsername = document.getElementById('config-username');
const configUseremail = document.getElementById('config-useremail');
const configPlanBadge = document.getElementById('config-plan-badge');
const configExpiry = document.getElementById('config-expiry');
const configActionsContainer = document.getElementById('config-actions-container');
const btnOpenWhatsapp = document.getElementById('btn-open-whatsapp');

// Elementos Upgrade
const viewUpgrade = document.getElementById('view-upgrade');
const btnBackFromUpgrade = document.getElementById('btn-back-from-upgrade');

// Elementos Funil
const viewFunil = document.getElementById('view-funil');
const btnNewFunnel = document.getElementById('btn-new-funnel');
const funnelListContainer = document.getElementById('funnel-list-container');
const funnelFormContainer = document.getElementById('funnel-form-container');
const formFunil = document.getElementById('form-funil');
const funnelIdInput = document.getElementById('funnel-id');
const funnelNameInput = document.getElementById('funnel-name');
const funnelTriggersInput = document.getElementById('funnel-triggers');
const funnelMessagesList = document.getElementById('funnel-messages-list');
const btnAddMessageSlot = document.getElementById('btn-add-message-slot');
const btnCancelFunnel = document.getElementById('btn-cancel-funnel');

// Elementos Anti-Banimento
const btnAntiBan = document.getElementById('btn-anti-ban');
const btnDashAntiBan = document.getElementById('btn-dash-anti-ban');
const antiBanModal = document.getElementById('anti-ban-modal');
const antiBanTerminalBody = document.getElementById('anti-ban-terminal-body');
const antiBanSuccessState = document.getElementById('anti-ban-success-state');

// Variáveis de Estado Local
let uploadedContacts = [];
let activeView = 'dashboard';

// --- INICIALIZAÇÃO ---
document.addEventListener('DOMContentLoaded', () => {
  verificarLicenca();
  setupEventListeners();
});

async function verificarLicenca() {
  showLoading('Verificando licença...');
  try {
    const res = await storage.get(['zapflow_license']);
    if (res.zapflow_license) {
      // Validar licença com o Supabase
      const license = res.zapflow_license;
      try {
        const key = license.license_key;
        const url = `https://zmozmydchgkunyxuwhgh.supabase.co/rest/v1/zapflow_licenses?select=expires_at,plan_type,disparos_limite&license_key=eq.${encodeURIComponent(key)}`;
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inptb3pteWRjaGdrdW55eHV3aGdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MjE2OTQsImV4cCI6MjA5NzM5NzY5NH0.dRKizn_OUA7e3bYxcJCQkEhDUq4h5lsRbQCe9dovPLo',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inptb3pteWRjaGdrdW55eHV3aGdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MjE2OTQsImV4cCI6MjA5NzM5NzY5NH0.dRKizn_OUA7e3bYxcJCQkEhDUq4h5lsRbQCe9dovPLo'
          }
        });

        if (response.ok) {
          const data = await response.json();
          if (data && data.length > 0) {
            const lic = data[0];
            const expiresAt = lic.expires_at ? new Date(lic.expires_at) : null;
            const now = new Date();
            
            if (expiresAt && expiresAt < now) {
              // Expirado
              await storage.remove(['zapflow_license']);
              hideLoading();
              if (appContainer) appContainer.classList.add('hidden');
              if (activationContainer) activationContainer.classList.remove('hidden');
              if (activationErrorMsg) {
                activationErrorMsg.textContent = 'Sua licença expirou. Renove seu plano no Gera Leads.';
                activationErrorMsg.classList.remove('hidden');
              }
              return;
            }

            // Atualiza dados locais caso tenham mudado no banco
            license.plan_type = lic.plan_type;
            license.disparos_limite = lic.disparos_limite;
            await storage.set({ zapflow_license: license });
          } else {
            // Licença não existe mais no banco
            await storage.remove(['zapflow_license']);
            hideLoading();
            if (appContainer) appContainer.classList.add('hidden');
            if (activationContainer) activationContainer.classList.remove('hidden');
            if (activationErrorMsg) {
              activationErrorMsg.textContent = 'Chave de licença inválida ou removida.';
              activationErrorMsg.classList.remove('hidden');
            }
            return;
          }
        }
      } catch (netErr) {
        console.error('Erro de rede ao validar licença online, usando dados locais:', netErr);
      }

      if (activationContainer) activationContainer.classList.add('hidden');
      await initApp();
    } else {
      hideLoading();
      if (appContainer) appContainer.classList.add('hidden');
      if (activationContainer) activationContainer.classList.remove('hidden');
    }
  } catch (err) {
    console.error('Erro ao verificar licença:', err);
    hideLoading();
  }
}

// Checar sessão e inicializar
async function initApp() {
  if (activationContainer) activationContainer.classList.add('hidden');
  if (appContainer) appContainer.classList.remove('hidden');
  
  // Configurar view inicial
  switchView('dashboard');
  
  // Atualizar status do WhatsApp
  verificarStatusWhatsApp();

  // Carregar dados
  await carregarDadosUsuario();
  await restaurarEstadosAtivos();

  hideLoading();
}

// Mostra/oculta loading global
function showLoading(text = 'Carregando...') {
  globalLoadingText.textContent = text;
  globalLoading.classList.remove('hidden');
}

function hideLoading() {
  globalLoading.classList.add('hidden');
}

// --- ROTEAMENTO ---
function switchView(viewName) {
  activeView = viewName;
  
  // Atualizar botões da sidebar
  navItems.forEach(item => {
    if (item.getAttribute('data-view') === viewName) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  // Ocultar todas as seções
  viewDashboard.classList.add('hidden');
  viewDisparos.classList.add('hidden');
  viewConfiguracoes.classList.add('hidden');
  if (viewDebugLogs) viewDebugLogs.classList.add('hidden');
  if (viewUpgrade) viewUpgrade.classList.add('hidden');
  if (viewFunil) viewFunil.classList.add('hidden');

  // Mostrar seção correta
  if (viewName === 'dashboard') {
    viewDashboard.classList.remove('hidden');
    carregarDadosUsuario();
    verificarStatusWhatsApp();
  } else if (viewName === 'disparos') {
    viewDisparos.classList.remove('hidden');
    verificarFilaPendenteDisparo();
  } else if (viewName === 'funil') {
    if (viewFunil) viewFunil.classList.remove('hidden');
    carregarFunis();
  } else if (viewName === 'configuracoes') {
    viewConfiguracoes.classList.remove('hidden');
    carregarDadosUsuario();
  } else if (viewName === 'debug-logs') {
    if (viewDebugLogs) viewDebugLogs.classList.remove('hidden');
    carregarDebugLogs();
  } else if (viewName === 'upgrade') {
    if (viewUpgrade) viewUpgrade.classList.remove('hidden');
    inicializarTelaUpgrade();
  }
}

// Mostrar banner de upgrade
function mostrarUpgradeBanner() {
  upgradeBanner.classList.remove('hidden');
}

// --- CONFIGURAÇÃO DE EVENTOS ---
function setupEventListeners() {
  // Ativação da Licença
  if (formActivation) {
    formActivation.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (activationErrorMsg) activationErrorMsg.classList.add('hidden');
      const key = activationKey.value.trim();
      if (!key) return;

      showLoading('Validando chave...');
      try {
        const url = `https://zmozmydchgkunyxuwhgh.supabase.co/rest/v1/zapflow_licenses?select=*&license_key=eq.${encodeURIComponent(key)}`;
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inptb3pteWRjaGdrdW55eHV3aGdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MjE2OTQsImV4cCI6MjA5NzM5NzY5NH0.dRKizn_OUA7e3bYxcJCQkEhDUq4h5lsRbQCe9dovPLo',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inptb3pteWRjaGdrdW55eHV3aGdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MjE2OTQsImV4cCI6MjA5NzM5NzY5NH0.dRKizn_OUA7e3bYxcJCQkEhDUq4h5lsRbQCe9dovPLo'
          }
        });

        if (!response.ok) {
          throw new Error('Falha ao comunicar com o servidor de licenças.');
        }

        const data = await response.json();
        
        if (data && data.length > 0) {
          const lic = data[0];
          
          // Verificar se a licença já está expirada antes de ativar
          const expiresAt = lic.expires_at ? new Date(lic.expires_at) : null;
          const now = new Date();
          
          if (expiresAt && expiresAt < now) {
            if (activationErrorMsg) {
              activationErrorMsg.textContent = 'Sua licença expirou. Renove seu plano no Gera Leads.';
              activationErrorMsg.classList.remove('hidden');
            }
            return;
          }

          const userName = lic.user_name || 'Usuário';
          const licenseObj = {
            license_key: lic.license_key,
            plan_type: lic.plan_type,
            disparos_limite: lic.disparos_limite,
            disparos_usados: lic.disparos_usados || 0,
            user_id: lic.user_id,
            user_name: userName
          };
          
          await storage.set({ zapflow_license: licenseObj });
          
          if (activationContainer) activationContainer.classList.add('hidden');
          await initApp();
        } else {
          if (activationErrorMsg) {
            activationErrorMsg.textContent = 'Chave inválida';
            activationErrorMsg.classList.remove('hidden');
          }
        }
      } catch (err) {
        if (activationErrorMsg) {
          activationErrorMsg.textContent = err.message || 'Erro ao validar chave.';
          activationErrorMsg.classList.remove('hidden');
        }
      } finally {
        hideLoading();
      }
    });
  }

  // Navegação Sidebar
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetView = item.getAttribute('data-view');
      switchView(targetView);
    });
  });

  // Desativar Licença
  const performLogout = async () => {
    if (confirm('Tem certeza de que deseja desativar a licença do ZapFlow?')) {
      showLoading('Desativando...');
      await storage.remove(['zapflow_license']);
      await verificarLicenca();
      hideLoading();
    }
  };
  if (btnSidebarLogout) btnSidebarLogout.addEventListener('click', performLogout);
  if (btnConfigLogout) btnConfigLogout.addEventListener('click', performLogout);

  // Fechar banner de upgrade
  btnCloseUpgrade.addEventListener('click', () => {
    upgradeBanner.classList.add('hidden');
  });

  // --- COMPONENTES DE DISPARO ---
  // --- COMPONENTES DE DISPARO ---

  // Contador de caracteres da mensagem
  campMessage.addEventListener('input', () => {
    msgCharCount.textContent = campMessage.value.length;
  });

  // Submeter envio de campanha
  formDisparos.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Verificar se o limite de disparos foi atingido
    try {
      const resStore = await storage.get(['zapflow_license']);
      const license = resStore.zapflow_license;
      if (license) {
        if (license.disparos_limite !== -1 && (license.disparos_usados || 0) >= license.disparos_limite) {
          alert('Limite de disparos atingido. Faça upgrade do seu plano.');
          return;
        }
      }
    } catch (err) {
      console.error('Erro ao validar licença no envio:', err);
    }
    
    // Parse contatos do textarea
    const rawText = contactsTextInput ? contactsTextInput.value || '' : '';
    const lines = rawText.split(/\r?\n/).map(line => line.trim()).filter(line => line.length > 0);
    const contatos = [];
    
    for (const line of lines) {
      const parts = line.split(/[;,]/).map(p => p.trim());
      const rawPhone = parts[0];
      const rawName = parts[1] || '';
      const phone = csvParser.cleanPhone(rawPhone);
      if (phone) {
        contatos.push({
          nome: rawName || 'Contato',
          numero: phone
        });
      }
    }

    if (contatos.length === 0) {
      alert('Por favor, insira pelo menos um número de contato válido na área de texto.');
      return;
    }
    
    uploadedContacts = contatos;

    showLoading('Preparando campanha...');
    try {
      // 1. Verificar conexão WhatsApp Web
      const statusWpp = await queryWhatsAppStatus();
      if (!statusWpp.conectado) {
        alert('WhatsApp Web não detectado ou desconectado. Por favor, abra-o no Chrome e faça login antes de iniciar os disparos.');
        switchView('configuracoes');
        return;
      }

      // 3. Criar campanha localmente
      const campId = 'camp_' + Date.now();

      // Incrementar o histórico de campanhas no storage
      try {
        const resStore = await storage.get(['total_campanhas']);
        const currentCount = resStore.total_campanhas || 0;
        await storage.set({ total_campanhas: currentCount + 1 });
      } catch (err) {
        console.error('Erro ao atualizar total_campanhas no storage:', err);
      }

      // 4. Iniciar fila em storage e background
      const campanhaAtiva = {
        id: campId,
        nome: campName.value,
        fila: uploadedContacts,
        progresso: 0,
        total: uploadedContacts.length,
        status: 'em_andamento',
        delay_min: parseInt(delayMin.value) || 3,
        delay_max: parseInt(delayMax.value) || 8,
        mensagem: campMessage.value,
        erros: 0,
        enviados: 0,
        ignorados: 0
      };

      await storage.set({
        campanha_ativa: campanhaAtiva,
        campanha_logs: []
      });

      // 5. Notificar Service Worker
      chrome.runtime.sendMessage({ action: 'START_CAMPAIGN' });

      // Exibir painel ativo
      formDisparos.classList.add('hidden');
      disparosActivePanel.classList.remove('hidden');
      renderizarPainelCampanha(campanhaAtiva, []);
      
    } catch (err) {
      alert(err.message || 'Erro ao iniciar campanha.');
    } finally {
      hideLoading();
    }
  });

  // Controles de Campanha Ativa
  // Controles de Campanha Ativa
  btnCampPause.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' });
  });

  btnCampResume.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'RESUME_CAMPAIGN' });
  });

  btnCampCancel.addEventListener('click', () => {
    if (confirm('Tem certeza de que deseja cancelar esta campanha? Os contatos restantes não serão processados.')) {
      showLoading('Cancelando campanha...');
      chrome.runtime.sendMessage({ action: 'CANCEL_CAMPAIGN' });
    }
  });



  // Configurações - Abrir WhatsApp Web
  btnOpenWhatsapp.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://web.whatsapp.com/' });
  });

  // Logs de Debug
  if (btnShowDebugLogs) {
    btnShowDebugLogs.addEventListener('click', () => {
      switchView('debug-logs');
    });
  }

  if (btnRunDiagnostic) {
    btnRunDiagnostic.addEventListener('click', () => {
      showLoading('Executando diagnóstico...');
      chrome.runtime.sendMessage({ action: 'RUN_DIAGNOSTIC' }, (response) => {
        hideLoading();
        if (chrome.runtime.lastError) {
          alert('Erro ao enviar mensagem para a extensão: ' + chrome.runtime.lastError.message);
          return;
        }
        if (response && response.sucesso) {
          alert('Diagnóstico concluído! Redirecionando para os logs.');
          switchView('debug-logs');
        } else {
          alert('Falha no diagnóstico: ' + (response ? response.erro : 'Sem resposta'));
        }
      });
    });
  }

  if (btnBackFromLogs) {
    btnBackFromLogs.addEventListener('click', () => {
      switchView('configuracoes');
    });
  }

  if (btnBackFromUpgrade) {
    btnBackFromUpgrade.addEventListener('click', () => {
      switchView('configuracoes');
    });
  }

  // Abas de periodicidade da tela de upgrade
  document.querySelectorAll('.upgrade-tabs .tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.upgrade-tabs .tab-btn').forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      selectedPeriod = e.currentTarget.getAttribute('data-period');
      atualizarPrecosPlanos();
    });
  });

  // Botões de checkout dos planos
  document.querySelectorAll('.plan-card .btn-checkout').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const planBase = e.currentTarget.getAttribute('data-plan-base');
      redirecionarCheckout(planBase);
    });
  });

  if (btnClearDebugLogs) {
    btnClearDebugLogs.addEventListener('click', async () => {
      if (confirm('Tem certeza de que deseja limpar todos os logs de debug?')) {
        await storage.remove(['debug_logs']);
        carregarDebugLogs();
      }
    });
  }

  if (btnCopyDebugLogs) {
    btnCopyDebugLogs.addEventListener('click', () => {
      const txt = debugLogsTextarea.value;
      navigator.clipboard.writeText(txt).then(() => {
        alert('Logs copiados para a área de transferência!');
      }).catch(err => {
        alert('Erro ao copiar logs: ' + err.message);
      });
    });
  }

  // --- FUNNEL LISTENERS ---
  if (btnNewFunnel) {
    btnNewFunnel.addEventListener('click', () => {
      abrirFormularioFunil(null);
    });
  }

  if (btnAddMessageSlot) {
    btnAddMessageSlot.addEventListener('click', () => {
      const slots = funnelMessagesList.querySelectorAll('.funnel-msg-slot');
      if (slots.length < 5) {
        adicionarSlotMensagem("", 5, 15);
      }
    });
  }

  if (btnCancelFunnel) {
    btnCancelFunnel.addEventListener('click', () => {
      carregarFunis();
    });
  }

  if (formFunil) {
    formFunil.addEventListener('submit', salvarFunilSubmit);
  }

  // --- ANTI-BAN LISTENERS ---
  if (btnAntiBan) {
    btnAntiBan.addEventListener('click', runAntiBanAnimation);
  }
  if (btnDashAntiBan) {
    btnDashAntiBan.addEventListener('click', runAntiBanAnimation);
  }

  // Escutar mudanças no storage (reativo)
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;

    // Reload funnels if changed in storage
    if (changes.funnels && activeView === 'funil') {
      carregarFunis();
    }

    // Update dashboard metrics on storage changes
    if (changes.funil_ativo) {
      carregarDadosUsuario();
    }

    // Atualização de campanha de disparos
    if (changes.campanha_ativa) {
      const camp = changes.campanha_ativa.newValue;
      if (camp) {
        storage.get(['campanha_logs']).then(res => {
          renderizarPainelCampanha(camp, res.campanha_logs || []);
        });
      } else {
        // Campanha limpa do storage (concluída ou cancelada)
        formDisparos.classList.remove('hidden');
        disparosActivePanel.classList.add('hidden');
        if (contactsTextInput) {
          contactsTextInput.value = '';
        }
        
        // Atualizar dashboard com novos limites consumidos
        carregarDadosUsuario();

        const oldCamp = changes.campanha_ativa.oldValue;
        if (oldCamp && oldCamp.status === 'em_andamento') {
          alert(`Campanha "${oldCamp.nome}" concluída!`);
        }
      }
    }

    // Logs de campanha recebidos em tempo real
    if (changes.campanha_logs) {
      const logs = changes.campanha_logs.newValue || [];
      storage.get(['campanha_ativa']).then(res => {
        if (res.campanha_ativa) {
          renderizarPainelCampanha(res.campanha_ativa, logs);
        }
      });
    }

    if (changes.debug_logs && activeView === 'debug-logs') {
      carregarDebugLogs();
    }
  });

}

// --- GERENCIAMENTO DE DADOS DO USUÁRIO ---
async function carregarDadosUsuario() {
  try {
    const resStore = await storage.get(['zapflow_license']);
    const license = resStore.zapflow_license;
    if (!license) return;

    // Atualizar boas-vindas do Dashboard
    const savedName = license.user_name || 'Usuário';
    dashWelcome.textContent = `Olá, ${savedName}`;
    
    const planoNome = license.plan_type || 'Basic';
    // Capitalizar o nome do plano
    const planoCompleto = planoNome.charAt(0).toUpperCase() + planoNome.slice(1);
    
    let planoBaseClass = 'basic';
    if (planoNome.toLowerCase().includes('pro')) {
      planoBaseClass = 'pro';
    } else if (planoNome.toLowerCase().includes('enterprise')) {
      planoBaseClass = 'enterprise';
    }
    
    dashPlanBadge.textContent = planoCompleto;
    dashPlanBadge.className = `plan-badge ${planoBaseClass}`;
    
    configPlanBadge.textContent = planoCompleto;
    configPlanBadge.className = `plan-badge ${planoBaseClass}`;
    
    configUsername.textContent = 'Licença ZapFlow';
    configUseremail.textContent = `Chave: ${license.license_key.substring(0, 8)}...`;

    // 1. Card: Total de disparos do mês atual (buscar do storage da licença)
    const limDisp = license.disparos_limite;
    const usdDisp = license.disparos_usados || 0;
    const limitText = limDisp === -1 ? 'Ilimitado' : limDisp.toLocaleString('pt-BR');
    statDisparos.textContent = `${usdDisp.toLocaleString('pt-BR')} / ${limitText}`;
    
    // Barra de progresso para consumo
    const pctDisp = limDisp === -1 || limDisp === 0 ? 0 : Math.min((usdDisp / limDisp) * 100, 100);
    progressDisparos.style.width = `${pctDisp}%`;

    // Alterar cor da barra de progresso com base no consumo (estilo Gera Leads)
    progressDisparos.className = 'progress-bar'; // reset
    if (limDisp !== -1) {
      if (usdDisp >= limDisp) {
        progressDisparos.classList.add('error');
      } else if (usdDisp >= limDisp * 0.8) {
        progressDisparos.classList.add('warning');
      } else {
        progressDisparos.classList.add('success');
      }
    } else {
      progressDisparos.classList.add('success');
    }

    // 2. Card: Disparos hoje (buscar do chrome.storage chave 'disparos_semana' filtrando pela data de hoje)
    const res = await storage.get(['disparos_semana']);
    const disparosSemana = res.disparos_semana || [];
    
    const d = new Date();
    const hojeStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const hojeItem = disparosSemana.find(item => item.data === hojeStr);
    const disparosHoje = hojeItem ? hojeItem.total : 0;
    
    if (statDisparosHoje) {
      statDisparosHoje.textContent = disparosHoje.toLocaleString('pt-BR');
    }

    // 4. Card: Campanhas realizadas (total histórico de campanhas do chrome.storage)
    let totalCampanhas = 0;
    try {
      const resCamp = await storage.get(['total_campanhas']);
      if (resCamp.total_campanhas !== undefined) {
        totalCampanhas = resCamp.total_campanhas;
      } else {
        totalCampanhas = 0;
        await storage.set({ total_campanhas: totalCampanhas });
      }
    } catch (err) {
      console.error('Erro ao buscar campanhas para o card do dashboard:', err);
    }
    
    if (statTotalCampanhas) {
      statTotalCampanhas.textContent = totalCampanhas.toLocaleString('pt-BR');
    }

    // Funnel metrics
    try {
      const resFunil = await storage.get(['funil_ativo']);
      const funilAtivo = resFunil.funil_ativo || {};
      let emFunilCount = 0;
      let convertidoCount = 0;
      let concluidoSemRespCount = 0;

      for (const phone in funilAtivo) {
        const item = funilAtivo[phone];
        if (item.status === 'em_funil') {
          emFunilCount++;
        } else if (item.status === 'convertido') {
          convertidoCount++;
        } else if (item.status === 'concluido_sem_resposta') {
          concluidoSemRespCount++;
        }
      }

      const statFunnelActive = document.getElementById('stat-funnel-active');
      const statFunnelConverted = document.getElementById('stat-funnel-converted');
      const statFunnelCompleted = document.getElementById('stat-funnel-completed');

      if (statFunnelActive) statFunnelActive.textContent = emFunilCount.toLocaleString('pt-BR');
      if (statFunnelConverted) statFunnelConverted.textContent = convertidoCount.toLocaleString('pt-BR');
      if (statFunnelCompleted) statFunnelCompleted.textContent = concluidoSemRespCount.toLocaleString('pt-BR');
    } catch (err) {
      console.error('Erro ao carregar métricas de funil:', err);
    }

    configExpiry.textContent = `Licença Ativa`;

    // Se o limite de disparos foi atingido
    if (limDisp !== -1 && usdDisp >= limDisp) {
      mostrarUpgradeBanner();
    } else {
      if (upgradeBanner) upgradeBanner.classList.add('hidden');
    }

    // Desabilitar o botão de iniciar disparos se o limite foi atingido
    const btnStartCampaign = document.getElementById('btn-start-campaign');
    if (btnStartCampaign) {
      if (limDisp !== -1 && usdDisp >= limDisp) {
        btnStartCampaign.disabled = true;
        btnStartCampaign.title = 'Limite de disparos atingido. Por favor, realize upgrade.';
      } else {
        btnStartCampaign.disabled = false;
        btnStartCampaign.title = '';
      }
    }

    // Ações de plano
    if (configActionsContainer) {
      configActionsContainer.innerHTML = ''; // Limpar anterior
    }

    // 5. Gráfico de barras: disparos por dia nos últimos 7 dias
    const dadosGrafico = gerarDadosGraficoUltimos7Dias(disparosSemana);
    desenharGrafico(dadosGrafico);

  } catch (err) {
    console.error('Erro ao carregar dados do usuário:', err);
  }
}

// Auxiliar para gerar os últimos 7 dias com base nos dados do storage
function gerarDadosGraficoUltimos7Dias(disparosSemana) {
  const dados = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    
    const itemExistente = disparosSemana.find(item => item.data === dateStr);
    dados.push({
      data: dateStr,
      total: itemExistente ? itemExistente.total : 0
    });
  }
  return dados;
}

// Auxiliar para gerar histórico vazio (caso necessário por compatibilidade externa)
function gerarDadosGraficoVazio() {
  const dados = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    dados.push({
      data: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`,
      total: 0
    });
  }
  return dados;
}

// Desenhar gráfico de barras (SVG puro)
function desenharGrafico(dados) {
  if (!dados || dados.length === 0) {
    dashChart.innerHTML = '<div class="no-chart-data">Sem dados para os últimos 7 dias.</div>';
    return;
  }

  const maxVal = Math.max(...dados.map(d => d.total), 1);
  const maxScaled = maxVal < 10 ? 10 : maxVal;

  const barWidth = 20;
  const gap = 25;
  const baselineY = 90;
  const maxBarHeight = 65;

  let svgContent = `
    <svg width="100%" height="100%" viewBox="0 0 340 110" xmlns="http://www.w3.org/2000/svg" style="background: transparent;">
      <defs>
        <linearGradient id="barGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#10B981" />
          <stop offset="100%" stop-color="#3B82F6" />
        </linearGradient>
      </defs>
      <line x1="15" y1="${baselineY}" x2="325" y2="${baselineY}" stroke="#27314B" stroke-width="1" />
  `;

  dados.forEach((item, index) => {
    const x = gap + index * (barWidth + gap);
    const h = (item.total / maxScaled) * maxBarHeight;
    const barHeight = Math.max(h, item.total > 0 ? 3 : 0);
    const y = baselineY - barHeight;
    
    const partes = item.data.split('-');
    const label = partes.length === 3 ? `${partes[2]}/${partes[1]}` : item.data;

    // Barra
    if (barHeight > 0) {
      svgContent += `
        <rect x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" rx="3" fill="url(#barGrad)" />
      `;
    }

    // Valor acima da barra
    if (item.total > 0) {
      svgContent += `
        <text x="${x + barWidth / 2}" y="${y - 4}" text-anchor="middle" fill="#F3F4F6" font-size="9" font-family="Outfit, sans-serif" font-weight="600">${item.total}</text>
      `;
    }

    // Label abaixo
    svgContent += `
      <text x="${x + barWidth / 2}" y="104" text-anchor="middle" fill="#6B7280" font-size="8" font-family="Outfit, sans-serif" font-weight="500">${label}</text>
    `;
  });

  svgContent += `</svg>`;
  dashChart.innerHTML = svgContent;
}

// --- VERIFICAR ESTADOS ATIVOS (Pós recarregamento do popup) ---
async function restaurarEstadosAtivos() {
  // 1. Verificar campanha de disparos ativa
  const resCamp = await storage.get(['campanha_ativa', 'campanha_logs']);
  if (resCamp.campanha_ativa) {
    formDisparos.classList.add('hidden');
    disparosActivePanel.classList.remove('hidden');
    renderizarPainelCampanha(resCamp.campanha_ativa, resCamp.campanha_logs || []);
    
    // Alternar pausada/ativa nos botões
    if (resCamp.campanha_ativa.status === 'pausada') {
      btnCampPause.classList.add('hidden');
      btnCampResume.classList.remove('hidden');
    } else {
      btnCampResume.classList.add('hidden');
      btnCampPause.classList.remove('hidden');
    }
  }


}

function verificarFilaPendenteDisparo() {
  storage.get(['lista_pendente_disparo']).then(res => {
    if (res.lista_pendente_disparo && res.lista_pendente_disparo.length > 0) {
      const contatos = res.lista_pendente_disparo;
      formDisparos.reset();
      campName.value = `Lista Importada - ${new Date().toLocaleDateString('pt-BR')}`;
      
      // Coloca os números na área de texto (formato: numero,nome)
      const txt = contatos.map(c => `${c.numero},${c.nome}`).join('\n');
      if (contactsTextInput) {
        contactsTextInput.value = txt;
      }
      
      uploadedContacts = contatos;
      
      // Limpa lista pendente para não carregar de novo na próxima visita
      storage.remove(['lista_pendente_disparo']);
    }
  });
}

// --- RENDERIZAR PAINÉIS DE PROGRESSO ---
function renderizarPainelCampanha(camp, logs) {
  activeCampTitle.textContent = `Campanha: ${camp.nome}`;
  
  const total = camp.total || 1;
  const processado = camp.enviados + camp.erros + camp.ignorados;
  
  activeCampProgressText.textContent = `${processado} / ${total}`;
  const pct = Math.min((processado / total) * 100, 100);
  activeCampProgressBar.style.width = `${pct}%`;

  // Renderizar logs (mais recentes no topo)
  const sortedLogs = [...logs].reverse().slice(0, 50); // limit 50 visual logs
  
  activeCampLogs.innerHTML = sortedLogs.map(log => {
    let statusClass = 'pending';
    let statusText = 'Enviando';
    if (log.status === 'enviado') {
      statusClass = 'success';
      statusText = 'Enviado';
    } else if (log.status === 'erro') {
      statusClass = 'error';
      statusText = 'Erro';
    } else if (log.status === 'invalido') {
      statusClass = 'error';
      statusText = 'Não Whats';
    }
    
    return `
      <div class="log-row">
        <span>${log.numero} (${log.nome || 'Contato'})</span>
        <span class="log-status ${statusClass}">${statusText}</span>
      </div>
    `;
  }).join('');

  // Toggle de botões baseado em status
  if (camp.status === 'pausada') {
    btnCampPause.classList.add('hidden');
    btnCampResume.classList.remove('hidden');
  } else {
    btnCampResume.classList.add('hidden');
    btnCampPause.classList.remove('hidden');
  }
}



// --- CONTROLE WHATSAPP STATUS ---
async function verificarStatusWhatsApp() {
  whatsappStatusBanner.className = 'whatsapp-status orange';
  whatsappStatusBanner.querySelector('.status-text').textContent = 'Desconectado';
  
  try {
    const status = await queryWhatsAppStatus();
    if (status.conectado) {
      whatsappStatusBanner.className = 'whatsapp-status green';
      whatsappStatusBanner.querySelector('.status-text').textContent = 'Conectado';
    } else {
      whatsappStatusBanner.className = 'whatsapp-status orange';
      whatsappStatusBanner.querySelector('.status-text').textContent = 'Desconectado';
    }
  } catch (err) {
    whatsappStatusBanner.className = 'whatsapp-status orange';
    whatsappStatusBanner.querySelector('.status-text').textContent = 'Desconectado';
  }
}

async function queryWhatsAppStatus() {
  return new Promise((resolve) => {
    chrome.tabs.query({ url: '*://web.whatsapp.com/*' }, (tabs) => {
      if (tabs.length === 0) {
        resolve({ conectado: false });
        return;
      }
      
      const targetTab = tabs.find(t => t.status === 'complete') || tabs[0];
      
      chrome.tabs.sendMessage(targetTab.id, { action: 'CHECK_CONNECTION' }, (response) => {
        if (chrome.runtime.lastError || !response) {
          // Tenta injetar o content script programaticamente se falhar
          chrome.scripting.executeScript({
            target: { tabId: targetTab.id },
            files: ['content_script.js']
          }, () => {
            if (chrome.runtime.lastError) {
              resolve({ conectado: false });
            } else {
              // Tenta verificar novamente após 500ms
              setTimeout(() => {
                chrome.tabs.sendMessage(targetTab.id, { action: 'CHECK_CONNECTION' }, (secondResponse) => {
                  if (chrome.runtime.lastError || !secondResponse) {
                    resolve({ conectado: false });
                  } else {
                    resolve(secondResponse);
                  }
                });
              }, 500);
            }
          });
        } else {
          resolve(response);
        }
      });
    });
  });
}

async function carregarDebugLogs() {
  if (!debugLogsTextarea) return;
  
  const res = await storage.get(['debug_logs']);
  const logs = res.debug_logs || [];
  
  if (logs.length === 0) {
    debugLogsTextarea.value = 'Nenhum log registrado até o momento...';
    return;
  }
  
  const formattedLogs = logs.map(log => {
    return `[${log.horario || log.timestamp}] Num: ${log.numero || 'N/A'} | Msg: ${log.mensagem}\n${log.url ? `URL: ${log.url}\n` : ''}${log.info && Object.keys(log.info).length > 0 ? `Info: ${JSON.stringify(log.info)}\n` : ''}----------------------------------------`;
  }).join('\n');
  
  debugLogsTextarea.value = formattedLogs;
}

// --- CONTROLE DA TELA DE UPGRADE ---
let selectedPeriod = 'mensal';

const planPrices = {
  mensal: {
    basic: { value: '47', period: '/mês' },
    pro: { value: '97', period: '/mês' },
    enterprise: { value: '297', period: '/mês' }
  },
  trimestral: {
    basic: { value: '120', period: '/trimestre' },
    pro: { value: '250', period: '/trimestre' },
    enterprise: { value: '750', period: '/trimestre' }
  },
  anual: {
    basic: { value: '400', period: '/ano' },
    pro: { value: '850', period: '/ano' },
    enterprise: { value: '2500', period: '/ano' }
  }
};

function inicializarTelaUpgrade() {
  selectedPeriod = 'mensal';
  
  // Resetar estados das abas
  const tabs = document.querySelectorAll('.upgrade-tabs .tab-btn');
  tabs.forEach(tab => {
    if (tab.getAttribute('data-period') === 'mensal') {
      tab.classList.add('active');
    } else {
      tab.classList.remove('active');
    }
  });

  atualizarPrecosPlanos();
}

function atualizarPrecosPlanos() {
  const prices = planPrices[selectedPeriod];
  if (!prices) return;

  const priceBasic = document.getElementById('price-basic');
  const labelBasic = document.getElementById('label-basic');
  if (priceBasic) priceBasic.textContent = prices.basic.value;
  if (labelBasic) labelBasic.textContent = prices.basic.period;

  const pricePro = document.getElementById('price-pro');
  const labelPro = document.getElementById('label-pro');
  if (pricePro) pricePro.textContent = prices.pro.value;
  if (labelPro) labelPro.textContent = prices.pro.period;

  const priceEnterprise = document.getElementById('price-enterprise');
  const labelEnterprise = document.getElementById('label-enterprise');
  if (priceEnterprise) priceEnterprise.textContent = prices.enterprise.value;
  if (labelEnterprise) labelEnterprise.textContent = prices.enterprise.period;
}

async function redirecionarCheckout(planBase) {
  alert('Por favor, acesse o painel do Gera Leads para gerenciar ou fazer o upgrade de seu plano.');
}

// --- SISTEMA DE FUNIL DE RESPOSTAS ---
async function carregarFunis() {
  funnelListContainer.classList.remove('hidden');
  funnelFormContainer.classList.add('hidden');

  const res = await storage.get(['funnels']);
  const funnels = res.funnels || [];

  if (funnels.length === 0) {
    funnelListContainer.innerHTML = `
      <div class="no-chart-data" style="text-align: center; margin: 24px 0;">
        Nenhum funil cadastrado.<br>Clique em "Novo Funil" para começar!
      </div>
    `;
    return;
  }

  funnelListContainer.innerHTML = funnels.map(f => {
    const activeChecked = f.active ? 'checked' : '';
    const triggerBadges = f.triggers.split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0)
      .map(t => `<span class="trigger-tag">${t}</span>`)
      .join(' ');

    return `
      <div class="funnel-card" data-id="${f.id}">
        <div class="funnel-card-header">
          <h3>${f.name}</h3>
          <label class="switch">
            <input type="checkbox" class="toggle-funnel-status" ${activeChecked}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="funnel-card-meta">
          <div class="triggers-row">
            Gatilhos: ${triggerBadges}
          </div>
        </div>
        <div class="funnel-card-footer">
          <span>${f.messages.length} ${f.messages.length === 1 ? 'mensagem' : 'mensagens'}</span>
          <div class="funnel-card-actions">
            <button class="btn-card-action btn-edit" title="Editar">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="icon-small"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="btn-card-action btn-delete" title="Excluir">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="icon-small"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  // Bind event listeners for actions inside cards
  funnelListContainer.querySelectorAll('.funnel-card').forEach(card => {
    const id = card.getAttribute('data-id');
    
    // Toggle active status
    const toggleInput = card.querySelector('.toggle-funnel-status');
    toggleInput.addEventListener('change', async (e) => {
      const res = await storage.get(['funnels']);
      const list = res.funnels || [];
      const f = list.find(item => item.id === id);
      if (f) {
        f.active = e.target.checked;
        await storage.set({ funnels: list });
      }
    });

    // Edit button
    const btnEdit = card.querySelector('.btn-edit');
    btnEdit.addEventListener('click', () => {
      const f = funnels.find(item => item.id === id);
      if (f) {
        abrirFormularioFunil(f);
      }
    });

    // Delete button
    const btnDelete = card.querySelector('.btn-delete');
    btnDelete.addEventListener('click', async () => {
      if (confirm('Deseja realmente excluir este funil?')) {
        const res = await storage.get(['funnels']);
        const list = res.funnels || [];
        const filtered = list.filter(item => item.id !== id);
        await storage.set({ funnels: filtered });
        carregarFunis();
      }
    });
  });
}

function abrirFormularioFunil(funnel = null) {
  funnelListContainer.classList.add('hidden');
  funnelFormContainer.classList.remove('hidden');
  funnelMessagesList.innerHTML = '';

  if (funnel) {
    document.getElementById('funnel-form-title').textContent = 'Editar Funil';
    funnelIdInput.value = funnel.id;
    funnelNameInput.value = funnel.name;
    funnelTriggersInput.value = funnel.triggers;

    funnel.messages.forEach(msg => {
      adicionarSlotMensagem(msg.text, msg.delay_min, msg.delay_max);
    });
  } else {
    document.getElementById('funnel-form-title').textContent = 'Novo Funil';
    funnelIdInput.value = '';
    formFunil.reset();
    adicionarSlotMensagem("", 5, 15);
  }
}

function adicionarSlotMensagem(text = "", delay_min = 5, delay_max = 15) {
  const currentSlots = funnelMessagesList.querySelectorAll('.funnel-msg-slot');
  const count = currentSlots.length;
  if (count >= 5) return;

  const slotNum = count + 1;
  const slotDiv = document.createElement('div');
  slotDiv.className = 'funnel-msg-slot';
  slotDiv.id = `funnel-msg-slot-${slotNum}`;

  slotDiv.innerHTML = `
    <div class="slot-header">
      <span>Mensagem ${slotNum}</span>
      ${slotNum > 1 ? `<button type="button" class="btn-remove-slot" data-slot="${slotNum}">&times;</button>` : ''}
    </div>
    <textarea class="funnel-msg-text" placeholder="Mensagem ${slotNum} com {{nome}}..." required>${text}</textarea>
    <div class="form-row">
      <div class="form-group">
        <label>Delay Mín (s)</label>
        <input type="number" class="funnel-msg-delay-min" value="${delay_min}" min="1" required>
      </div>
      <div class="form-group">
        <label>Delay Máx (s)</label>
        <input type="number" class="funnel-msg-delay-max" value="${delay_max}" min="2" required>
      </div>
    </div>
  `;

  funnelMessagesList.appendChild(slotDiv);

  if (slotNum > 1) {
    const btnRemove = slotDiv.querySelector('.btn-remove-slot');
    btnRemove.addEventListener('click', () => {
      slotDiv.remove();
      reordenarSlotsMensagens();
    });
  }

  atualizarBotaoAddMessage();
}

function reordenarSlotsMensagens() {
  const slots = funnelMessagesList.querySelectorAll('.funnel-msg-slot');
  const data = [];
  slots.forEach(slot => {
    data.push({
      text: slot.querySelector('.funnel-msg-text').value,
      delay_min: slot.querySelector('.funnel-msg-delay-min').value,
      delay_max: slot.querySelector('.funnel-msg-delay-max').value
    });
  });

  funnelMessagesList.innerHTML = '';
  data.forEach(item => {
    adicionarSlotMensagem(item.text, item.delay_min, item.delay_max);
  });
}

function atualizarBotaoAddMessage() {
  const count = funnelMessagesList.querySelectorAll('.funnel-msg-slot').length;
  if (count >= 5) {
    btnAddMessageSlot.classList.add('hidden');
  } else {
    btnAddMessageSlot.classList.remove('hidden');
  }
}

async function salvarFunilSubmit(e) {
  e.preventDefault();
  
  const id = funnelIdInput.value || 'fn_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  const name = funnelNameInput.value.trim();
  const triggers = funnelTriggersInput.value.trim();

  const slots = funnelMessagesList.querySelectorAll('.funnel-msg-slot');
  const messages = [];

  for (const slot of slots) {
    const text = slot.querySelector('.funnel-msg-text').value.trim();
    const delay_min = parseInt(slot.querySelector('.funnel-msg-delay-min').value);
    const delay_max = parseInt(slot.querySelector('.funnel-msg-delay-max').value);

    if (!text) {
      alert('Todas as mensagens adicionadas precisam conter texto.');
      return;
    }

    if (delay_min <= 0 || delay_max <= 0 || delay_min > delay_max) {
      alert('O delay mínimo deve ser maior que zero e menor ou igual ao delay máximo.');
      return;
    }

    messages.push({ text, delay_min, delay_max });
  }

  if (messages.length === 0) {
    alert('Adicione pelo menos uma mensagem ao funil.');
    return;
  }

  showLoading('Salvando funil...');
  try {
    const res = await storage.get(['funnels']);
    const list = res.funnels || [];
    
    const existingIndex = list.findIndex(item => item.id === id);
    const funnelObj = {
      id,
      name,
      triggers,
      active: existingIndex !== -1 ? list[existingIndex].active : true,
      messages
    };

    if (existingIndex !== -1) {
      list[existingIndex] = funnelObj;
    } else {
      list.push(funnelObj);
    }

    await storage.set({ funnels: list });
    carregarFunis();
  } catch (err) {
    alert('Erro ao salvar funil: ' + err.message);
  } finally {
    hideLoading();
  }
}

// --- ANTI-BAN FEATURE LOGIC ---
const antiBanMessages = [
  "🔍 Verificando padrões de comportamento...",
  "🛡️ Aplicando rotação de delays...",
  "🔄 Limpando cache de sessão...",
  "⚙️ Ajustando fingerprint do navegador...",
  "🧹 Removendo rastros de automação...",
  "✅ Limpeza concluída."
];

function typeMessage(message, container) {
  return new Promise((resolve) => {
    const lineDiv = document.createElement('div');
    lineDiv.className = 'terminal-line';
    container.appendChild(lineDiv);
    container.scrollTop = container.scrollHeight;

    let index = 0;
    const cursor = document.createElement('span');
    cursor.className = 'cursor';
    lineDiv.appendChild(cursor);

    const interval = setInterval(() => {
      if (index < message.length) {
        const char = message[index];
        const textNode = document.createTextNode(char);
        lineDiv.insertBefore(textNode, cursor);
        index++;
        container.scrollTop = container.scrollHeight;
      } else {
        clearInterval(interval);
        cursor.remove();
        resolve();
      }
    }, 20);
  });
}

async function runAntiBanAnimation() {
  if (!antiBanModal || !antiBanTerminalBody || !antiBanSuccessState) return;

  antiBanModal.classList.remove('hidden');
  antiBanTerminalBody.innerHTML = '';
  antiBanSuccessState.classList.add('hidden');

  for (const message of antiBanMessages) {
    await typeMessage(message, antiBanTerminalBody);
    await new Promise(resolve => setTimeout(resolve, 350));
  }

  antiBanSuccessState.classList.remove('hidden');

  setTimeout(() => {
    antiBanModal.classList.add('hidden');
  }, 2000);
}



