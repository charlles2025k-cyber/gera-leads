(function() {
if (window.zapFlowLoaded) {
  console.log('[ZapFlow CS] Script já estava carregado. Evitando injeção duplicada.');
  return;
}
window.zapFlowLoaded = true;

console.log('[ZapFlow CS] Script injetado com sucesso!');

// --- ESCUTA DE MENSAGENS DO POPUP E BACKGROUND ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const hostname = window.location.hostname;

  // --- LOGICA WHATSAPP WEB ---
  if (hostname.includes('web.whatsapp.com')) {
    if (request.action === 'CHECK_CONNECTION') {
      const chatList = document.querySelector('[data-testid="chat-list"]') || 
                       document.querySelector('div[role="navigation"]');
      sendResponse({ conectado: !!chatList });
      return true;
    }
  }
});

// Map to keep track of processed message IDs to prevent duplicates
var processedMessageIds = window.processedMessageIds || new Set();
window.processedMessageIds = processedMessageIds;
var lastProcessedTextByPhone = window.lastProcessedTextByPhone || new Map();
window.lastProcessedTextByPhone = lastProcessedTextByPhone;
var lastUnreadCountByPhone = window.lastUnreadCountByPhone || new Map();
window.lastUnreadCountByPhone = lastUnreadCountByPhone;

// Helper to clean phone numbers
function cleanPhone(phone) {
  if (!phone) return null;
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length < 10 || cleaned.length > 13) return null;
  return cleaned;
}

// Function to handle a new incoming message from the DOM
function handleIncomingMessage(phone, text, msgId) {
  try {
    console.log(`[ZapFlow CS] handleIncomingMessage chamado. Phone: ${phone}, Text: "${text}", MsgId: ${msgId}`);
    if (!phone || !text) return;
    
    const cleanedPhone = cleanPhone(phone);
    if (!cleanedPhone) return;

    const now = Date.now();

    // For active bubbles, verify via unique message ID
    if (msgId) {
      if (processedMessageIds.has(msgId)) {
        console.log(`[ZapFlow CS] MsgId ${msgId} já foi processado anteriormente. Ignorando.`);
        return;
      }
      processedMessageIds.add(msgId);
      if (processedMessageIds.size > 1000) {
        const firstKey = processedMessageIds.keys().next().value;
        processedMessageIds.delete(firstKey);
      }
    } else {
      // For chat list rows (no direct msgId), verify via timestamp changes
      const lastData = lastProcessedTextByPhone.get(cleanedPhone);
      if (lastData && lastData.text === text && (now - lastData.timestamp < 30000)) {
        console.log(`[ZapFlow CS] Mensagem duplicada ignorada (enviada há menos de 30s): ${cleanedPhone} -> "${text}"`);
        return;
      }
      
      lastProcessedTextByPhone.set(cleanedPhone, { text: text, timestamp: now });
      if (lastProcessedTextByPhone.size > 100) {
        const firstKey = lastProcessedTextByPhone.keys().next().value;
        lastProcessedTextByPhone.delete(firstKey);
      }
    }

    console.log('[ZapFlow CS] Mensagem detectada e enviada:', cleanedPhone, text);
    try {
      chrome.runtime.sendMessage({
        action: 'INCOMING_MESSAGE',
        phone: cleanedPhone,
        text: text
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error(`[ZapFlow CS] Erro ao enviar mensagem para background:`, chrome.runtime.lastError.message);
        } else {
          console.log(`[ZapFlow CS] Envio bem-sucedido. Resposta do background:`, response);
        }
      });
    } catch (e) {
      console.log('[ZapFlow CS] Contexto invalidado ao enviar mensagem, ignorando:', e.message);
    }
  } catch (err) {
    console.error('[ZapFlow CS] Erro no escopo do handleIncomingMessage (provável contexto invalidado):', err.message);
  }
}

// Scans active conversation message elements
function scanActiveChatMessages() {
  try {
    const main = document.querySelector('#main');
    if (!main) return;

    // Diagnósticos para depuração no console
    const allDataIdNodes = main.querySelectorAll('[data-id]');
    console.log(`[ZapFlow CS] scanActiveChatMessages: Total com data-id em #main = ${allDataIdNodes.length}`);
    if (allDataIdNodes.length > 0) {
      const sampleIds = Array.from(allDataIdNodes).slice(-5).map(el => el.getAttribute('data-id'));
      console.log('[ZapFlow CS] scanActiveChatMessages: Amostra últimos 5 data-ids =', sampleIds);
    }

    // Tenta extrair o JID/telefone do chat ativo usando React Fiber
    let phone = findJidFromReact(main);
    if (!phone) {
      const header = main.querySelector('header');
      if (header) {
        phone = findJidFromReact(header);
      }
    }

    // Filtra nós de mensagens recebidas (contendo "false" no data-id, indicando fromMe: false)
    const msgNodes = Array.from(allDataIdNodes).filter(node => {
      const dataId = node.getAttribute('data-id') || '';
      return dataId.includes('false') || node.classList.contains('message-in');
    });

    if (msgNodes.length === 0) {
      console.log('[ZapFlow CS] Nenhuma mensagem recebida (fromMe: false) encontrada no chat ativo.');
      return;
    }
    
    console.log(`[ZapFlow CS] scanActiveChatMessages encontrou ${msgNodes.length} nós de mensagens recebidas no chat ativo.`);
    
    // Processamos apenas a última mensagem recebida (a mais recente na parte inferior do chat)
    const lastNode = msgNodes[msgNodes.length - 1];
    const dataId = lastNode.getAttribute('data-id');
    
    // Se não conseguimos extrair via React Fiber no #main, tenta a partir do data-id das mensagens
    if (!phone && dataId) {
      const match = dataId.match(/false_(\d+)@c\.us/) || dataId.match(/(\d+)@c\.us_false/);
      if (match) {
        phone = match[1];
      }
    }

    if (!phone) {
      // Tenta varrer outras mensagens recebidas para ver se alguma tem o JID estruturado no data-id
      for (let i = msgNodes.length - 1; i >= 0; i--) {
        const dId = msgNodes[i].getAttribute('data-id');
        if (dId) {
          const match = dId.match(/false_(\d+)@c\.us/) || dId.match(/(\d+)@c\.us_false/);
          if (match) {
            phone = match[1];
            break;
          }
        }
      }
    }

    const cleanedPhone = cleanPhone(phone);
    if (!cleanedPhone) {
      console.log('[ZapFlow CS] Não foi possível extrair um telefone válido para o chat ativo.');
      return;
    }

    const textEl = lastNode.querySelector('span.selectable-text') || 
                   lastNode.querySelector('.copyable-text') || 
                   lastNode.querySelector('.selectable-text');
    
    const text = textEl ? textEl.textContent.trim() : lastNode.textContent.trim();

    if (text) {
      handleIncomingMessage(cleanedPhone, text, dataId);
    }
  } catch (err) {
    console.error('[ZapFlow CS] Erro no scanActiveChatMessages:', err.message);
  }
}

// Busca recursiva nas propriedades internas do React Fiber / Props para localizar o JID
function findJidFromReact(el) {
  try {
    const keys = Object.getOwnPropertyNames(el);
    const reactKey = keys.find(k => 
      k.startsWith('__reactFiber$') || 
      k.startsWith('__reactInternalInstance$') || 
      k.startsWith('__reactProps$')
    );
    if (!reactKey) return null;
    
    const rootObj = el[reactKey];
    const visited = new WeakSet();
    
    function scanObject(obj, depth = 0) {
      if (!obj || depth > 12) return null;
      if (typeof obj === 'object') {
        if (visited.has(obj)) return null;
        visited.add(obj);
      }
      
      // Formato típico do WhatsApp JID object: { user: "5511999999999", server: "c.us" }
      if (obj.user && obj.server === 'c.us') {
        const cleaned = obj.user.replace(/\D/g, '');
        if (cleaned.length >= 10 && cleaned.length <= 13) {
          return cleaned;
        }
      }
      
      if (typeof obj === 'string' && obj.includes('@c.us')) {
        const match = obj.match(/(\d+)@c\.us/);
        if (match) {
          const cleaned = match[1].replace(/\D/g, '');
          if (cleaned.length >= 10 && cleaned.length <= 13) {
            return cleaned;
          }
        }
      }
      
      if (typeof obj === 'object') {
        for (const k in obj) {
          if (k.startsWith('__') || k === 'return' || k === 'child' || k === 'sibling' || k === 'stateNode') continue;
          try {
            const found = scanObject(obj[k], depth + 1);
            if (found) return found;
          } catch (e) {}
        }
      }
      return null;
    }

    return scanObject(rootObj);
  } catch (err) {
    // Falha silenciosa no parseamento do React
  }
  return null;
}

// Executa todas as estratégias de extração do telefone
async function extrairTelefoneDaLinha(row) {
  const elements = [row, ...row.querySelectorAll('*')];

  // 1. Tenta via React Fiber / Props
  for (const el of elements) {
    const jid = findJidFromReact(el);
    if (jid) {
      console.log('[ZapFlow CS] Telefone extraído via React Fiber:', jid);
      return jid;
    }
  }

  // 2. Tenta via atributos com @c.us
  for (const el of elements) {
    if (!el.attributes) continue;
    for (const attr of el.attributes) {
      if (attr.value && attr.value.includes('@c.us')) {
        const match = attr.value.match(/(\d+)@c\.us/);
        if (match) {
          const cleaned = match[1].replace(/\D/g, '');
          if (cleaned.length >= 10 && cleaned.length <= 13) {
            console.log('[ZapFlow CS] Telefone extraído via atributo @c.us:', cleaned);
            return cleaned;
          }
        }
      }
    }
  }

  // 3. Tenta via imagem de perfil tradicional
  const img = row.querySelector('img');
  if (img && img.src) {
    const match = img.src.match(/[?&]u=(\d+)/);
    if (match) {
      const cleaned = match[1].replace(/\D/g, '');
      if (cleaned.length >= 10 && cleaned.length <= 13) {
        console.log('[ZapFlow CS] Telefone extraído via img.src:', cleaned);
        return cleaned;
      }
    }
  }

  // 4. Tenta ver se o próprio título já é o telefone limpo
  const titleEl = row.querySelector('[title]');
  const titleText = titleEl ? titleEl.getAttribute('title') : '';
  if (titleText) {
    const cleaned = titleText.replace(/\D/g, '');
    if (cleaned.length >= 10 && cleaned.length <= 13) {
      console.log('[ZapFlow CS] Telefone extraído via título numérico:', cleaned);
      return cleaned;
    }
  }

  // 5. Tenta regex de telefone em outros atributos (aria-label com números formatados)
  for (const el of elements) {
    if (!el.attributes) continue;
    for (const attr of el.attributes) {
      if (!attr.value) continue;
      const val = attr.value.trim();
      const match = val.match(/\+?\d+[\s-]?\(?\d{2,3}\)?[\s-]?\d{4,5}[\s-]?\d{4}/);
      if (match) {
        const cleaned = match[0].replace(/\D/g, '');
        if (cleaned.length >= 10 && cleaned.length <= 13) {
          console.log('[ZapFlow CS] Telefone extraído via Regex de atributo:', cleaned);
          return cleaned;
        }
      }
    }
  }

  // 6. Tenta buscar no banco local
  if (titleText) {
    const phoneFromDb = await encontrarTelefonePorNome(titleText);
    if (phoneFromDb) {
      const cleaned = phoneFromDb.replace(/\D/g, '');
      if (cleaned.length >= 10 && cleaned.length <= 13) {
        console.log('[ZapFlow CS] Telefone extraído via histórico do ZapFlow:', cleaned);
        return cleaned;
      }
    }
  }

  return null;
}

// Scans the chat list for unread badges
function scanChatListForUnread() {
  try {
    console.log('[ZapFlow CS] Scanning chat list...');
    
    const selectors = [
      '[data-testid="list-item"]',
      'div[data-testid="cell-frame-container"]',
      'div[role="listitem"]',
      'div[data-testid="chat-list"] > div > div',
      'div[role="row"]'
    ];
    
    let rows = [];
    for (const selector of selectors) {
      const found = document.querySelectorAll(selector);
      if (found.length > 0) {
        rows = Array.from(found);
        console.log(`[ZapFlow CS] Seletor bem-sucedido: "${selector}". Encontradas:`, rows.length);
        break;
      }
    }

    console.log('[ZapFlow CS] Total rows encontradas:', rows.length);
    
    rows.forEach(async (row, idx) => {
      try {
        if (idx < 5) {
          console.log(`[ZapFlow CS] Row #${idx} HTML (primeiros 200 chars):`, row.innerHTML.substring(0, 200));
        }

        const badgeEl = row.querySelector('[data-testid="icon-unread-count"]') ||
                        row.querySelector('[aria-label*="unread"]') || 
                        row.querySelector('[aria-label*="lida"]') ||
                        row.querySelector('[aria-label*="lidas"]') ||
                        row.querySelector('span[class*="unread"]') ||
                        row.querySelector('div[class*="unread"]');

        let unreadCount = 0;
        if (badgeEl) {
          const text = badgeEl.textContent.trim();
          const ariaLabel = badgeEl.getAttribute('aria-label') || '';
          const match = ariaLabel.match(/(\d+)/);
          
          if (match) {
            unreadCount = parseInt(match[1], 10);
          } else if (text) {
            unreadCount = parseInt(text, 10);
          }
          
          if (isNaN(unreadCount) || unreadCount <= 0) {
            unreadCount = 1;
          }
        }

        // Tenta obter o telefone com as novas estratégias robustas
        const phone = await extrairTelefoneDaLinha(row);

        const titleEl = row.querySelector('[title]');
        const titleText = titleEl ? titleEl.getAttribute('title') : '';

        // Chave de rastreamento: prioriza telefone, depois título do contato, depois indexador da linha
        const trackingKey = phone || titleText || `row-${idx}`;
        const prevCount = lastUnreadCountByPhone.get(trackingKey);

        if (badgeEl) {
          console.log('[ZapFlow CS] Badge encontrado. Phone:', phone, 'Count:', unreadCount, 'Prev:', prevCount, 'Title:', titleText);
        }

        // Atualiza o rastreamento local com base na chave identificadora
        lastUnreadCountByPhone.set(trackingKey, unreadCount);

        // Se o contador for 0, não há nada a fazer
        if (unreadCount === 0) return;

        // Se for baseline (primeira leitura), só registra e retorna
        if (prevCount === undefined) {
          console.log(`[ZapFlow CS] Baselined unread count para ${trackingKey}: ${unreadCount}`);
          return;
        }

        // Só dispara se o contador aumentou
        if (unreadCount > prevCount) {
          console.log(`[ZapFlow CS] Contador não lidas aumentou para ${trackingKey}: ${prevCount} -> ${unreadCount}`);

          if (!phone) {
            // Se o telefone falhar por completo, abre o chat temporariamente
            console.log(`[ZapFlow CS] Telefone nulo para ${trackingKey}. Clicando na linha para abrir o chat.`);
            row.click();
            const clickable = row.querySelector('[role="button"]') || row.querySelector('div[role="row"]') || row;
            if (clickable && clickable !== row) {
              clickable.click();
            }
            const cellFrame = row.querySelector('div[data-testid="cell-frame-container"]');
            if (cellFrame) {
              cellFrame.click();
            }
            // Primeira tentativa aos 3000ms
            setTimeout(() => {
              try {
                console.log('[ZapFlow CS] Chamando scanActiveChatMessages após abrir chat (Tentativa 1 - 3000ms)...');
                scanActiveChatMessages();
              } catch (e) {
                console.error('[ZapFlow CS] Erro ao chamar scanActiveChatMessages no timeout de 3000ms:', e.message);
              }
            }, 3000);
            // Segunda tentativa aos 5000ms
            setTimeout(() => {
              try {
                console.log('[ZapFlow CS] Chamando scanActiveChatMessages após abrir chat (Tentativa 2 - 5000ms)...');
                scanActiveChatMessages();
              } catch (e) {
                console.error('[ZapFlow CS] Erro ao chamar scanActiveChatMessages no timeout de 5000ms:', e.message);
              }
            }, 5000);
            return;
          }

          const lastMsgContainer = row.querySelector('[data-testid="last-msg-status"]')?.parentElement || 
                                   row.querySelector('span[class*="last-msg"]') ||
                                   row.querySelector('div[class*="last-msg"]');
          
          let text = "";
          if (lastMsgContainer) {
            text = lastMsgContainer.textContent.trim();
          } else {
            const textEls = row.querySelectorAll('span');
            if (textEls.length > 2) {
              text = textEls[textEls.length - 2].textContent.trim();
            }
          }

          text = text.replace(/^\d+:\d+\s*(AM|PM)?/i, '').trim();

          if (text) {
            console.log('[ZapFlow CS] Nova mensagem detectada na lista:', phone, text);
            handleIncomingMessage(phone, text, null);
          }
        }
      } catch (err) {
        console.error('[ZapFlow CS] Erro no processamento da linha do chat:', err.message);
      }
    });
  } catch (err) {
    console.error('[ZapFlow CS] Erro no scanChatListForUnread:', err.message);
  }
}

async function encontrarTelefonePorNome(nome) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['campanha_logs', 'campanha_ativa'], (res) => {
        try {
          if (chrome.runtime.lastError) {
            console.error('[ZapFlow CS] Erro ao acessar storage:', chrome.runtime.lastError.message);
            resolve(null);
            return;
          }
          const logs = res.campanha_logs || [];
          const camp = res.campanha_ativa;
          
          const foundLog = logs.find(c => c.nome.toLowerCase() === nome.toLowerCase());
          if (foundLog) {
            resolve(foundLog.numero);
            return;
          }
          
          if (camp && camp.fila) {
            const foundQueue = camp.fila.find(c => c.nome.toLowerCase() === nome.toLowerCase());
            if (foundQueue) {
              resolve(foundQueue.numero);
              return;
            }
          }
          
          resolve(null);
        } catch (e) {
          console.log('[ZapFlow CS] Erro no callback de storage (contexto invalidado?):', e.message);
          resolve(null);
        }
      });
    } catch (e) {
      console.log('[ZapFlow CS] Contexto invalidado ao ler storage:', e.message);
      resolve(null);
    }
  });
}

let scanTimeout = null;
function triggerScan() {
  if (scanTimeout) return;
  scanTimeout = setTimeout(() => {
    scanActiveChatMessages();
    scanChatListForUnread();
    scanTimeout = null;
  }, 300);
}

function startReplyObserver() {
  console.log(`[ZapFlow CS] startReplyObserver inicializado.`);
  const observer = new MutationObserver((mutations) => {
    try {
      console.log('[ZapFlow CS] MutationObserver disparou!');
      triggerScan();
    } catch (e) {
      console.log('[ZapFlow CS] Erro no callback do MutationObserver:', e.message);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true
  });

  triggerScan();
}

if (window.location.hostname.includes('web.whatsapp.com')) {
  console.log(`[ZapFlow CS] Content script carregado em ${window.location.href}. Aguardando chat-list...`);
  const checkInterval = setInterval(() => {
    try {
      const chatList = document.querySelector('[data-testid="chat-list"]') || 
                       document.querySelector('div[role="navigation"]');
      if (chatList) {
        clearInterval(checkInterval);
        console.log('[ZapFlow CS] Chat-list localizado. Iniciando startReplyObserver...');
        startReplyObserver();

        // Fallback: scan every 2 seconds for unread messages
        setInterval(() => {
          try {
            console.log('[ZapFlow CS] Interval scan rodando...');
            scanChatListForUnread();
            scanActiveChatMessages();
          } catch (e) {
            console.log('[ZapFlow CS] Erro no interval scan:', e.message);
          }
        }, 2000);
      }
    } catch (e) {
      console.log('[ZapFlow CS] Erro no checkInterval:', e.message);
    }
  }, 2000);
}

})();

